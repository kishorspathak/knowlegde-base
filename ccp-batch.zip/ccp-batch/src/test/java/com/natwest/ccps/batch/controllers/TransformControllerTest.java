//package com.ccp.batch.controllers;
//
//import com.ccp.batch.model.RecordCommunicationCaseDetailsResponseData;
//import com.ccp.batch.model.Request;
//import com.ccp.batch.model.RetrieveContactPreferencesResponseData;
//import com.ccp.batch.model.RetrieveCustomersForArrResponseData;
//import com.ccp.batch.service.TransformService;
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.serviceparameters.v01.RetrieveContactPreferencesContent;
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.serviceparameters.v01.RetrieveContactPreferencesResponse;
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.transferobjects.v01.ContactPointTO;
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.transferobjects.v01.ContactPreferenceTO;
//import com.rbsg.soa.c080involvedpartymanagement.customerarrangementmanagement.v03.serviceparameters.v01.RetrieveCustomersForArrResponse;
//import com.rbsg.soa.c170communicationmanagement.communicationmanagement.v01.serviceparameters.v01.RecordCommunicationCaseDetailsContent;
//import com.rbsg.soa.c170communicationmanagement.communicationmanagement.v01.serviceparameters.v01.RecordCommunicationCaseDetailsResponse;
//import com.rbsg.soa.datatypes.primitivedatatypes.v03.AddressComponent;
//import com.rbsg.soa.services.definitions.v03.ProcessingIdentifier;
//import com.rbsg.soa.services.definitions.v03.ResponseHeader;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.test.web.servlet.RequestBuilder;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//import static org.mockito.Mockito.any;
//import static org.mockito.Mockito.when;
//
//class TransformControllerTest {
//    @Mock
//    TransformService transformService;
//    @InjectMocks
//    CcpBatchController transformController;
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    void testRetrieveContactPreferences() {
//        when(transformService.getRetrieveContactPreferences(any())).thenReturn(new RetrieveContactPreferencesResponseData());
//        ResponseEntity<RetrieveContactPreferencesResponseData> result = transformController.retrieveContactPreferences(new RetrieveContactPreferencesResponse());
//
//        RetrieveContactPreferencesResponse recordCommunicationCaseDetailsContent = new RetrieveContactPreferencesResponse();
//        RetrieveContactPreferencesContent response = new RetrieveContactPreferencesContent();
//        List<ContactPreferenceTO> contactPreferenceTOS = new ArrayList<>();
//        ContactPreferenceTO contactPreferenceTO = new ContactPreferenceTO();
//        ContactPointTO contactPointTO = new ContactPointTO();
//        List<AddressComponent> hasComponent = new ArrayList<>();
//        AddressComponent addressComponent = new AddressComponent();
//        addressComponent.getAddress().add("JO CASE");
//        addressComponent.setCodeValue("AddresseeLine1");
//        addressComponent.setSchemeName("PostalAddressComponentType");
//        hasComponent.add(addressComponent);
//        contactPointTO.getHasComponent().add(addressComponent);
//        contactPreferenceTO.getContactPoint().add(contactPointTO);
//        contactPreferenceTOS.add(contactPreferenceTO);
//        response.getContactPreferences().add(contactPreferenceTO);
//        recordCommunicationCaseDetailsContent.setResponse(response);
//
//        RetrieveContactPreferencesResponseData retrieveContactPreferencesResponseData = new RetrieveContactPreferencesResponseData();
//        retrieveContactPreferencesResponseData.setStatus("200");
//        retrieveContactPreferencesResponseData.setMessage("Address Information");
//        retrieveContactPreferencesResponseData.setTimestamp(new Date());
//        retrieveContactPreferencesResponseData.setData(recordCommunicationCaseDetailsContent);
//
//        Assertions.assertEquals(new ResponseEntity<>(transformService.getRetrieveContactPreferences(recordCommunicationCaseDetailsContent), HttpStatus.OK), result);
//    }
//
//    @Test
//    void testRetrieveCustomersForArr() {
//        when(transformService.getRetrieveCustomersForArrResponse(any())).thenReturn(new RetrieveCustomersForArrResponseData());
//
//        ResponseEntity<RetrieveCustomersForArrResponseData> result = transformController.retrieveCustomersForArr(new RetrieveCustomersForArrResponse());
//        Assertions.assertEquals(null, result);
//    }
//
//    @Test
//    void testRecordCommunicationCaseDetails() {
//        when(transformService.getRecordCommunicationCaseDetailsResponse(any())).thenReturn(new RecordCommunicationCaseDetailsResponseData());
//
//        ResponseEntity<RecordCommunicationCaseDetailsResponseData> result = transformController.recordCommunicationCaseDetails(new RecordCommunicationCaseDetailsResponse());
//
//        RecordCommunicationCaseDetailsResponse recordCommunicationCaseDetailsResponse = new RecordCommunicationCaseDetailsResponse();
//        RecordCommunicationCaseDetailsContent recordCommunicationCaseDetailsContent = new RecordCommunicationCaseDetailsContent();
//        ResponseHeader responseHeader = new ResponseHeader();
//        ProcessingIdentifier processingIdentifier = new ProcessingIdentifier();
//        processingIdentifier.setTransactionId("ESP");
//        processingIdentifier.setSystemId("3fbS1c3fdecbf6076b1972b8fc00120210414101047822h");
//        processingIdentifier.setTransactionId("ESP");
//        processingIdentifier.setSystemId("3fbS1c3fdecbf6076b1972b8fc00120210414101047822h");
//        processingIdentifier.setTransactionId("ESP");
//        processingIdentifier.setSystemId("3fbS1c3fdecbf6076b1972b8fc00120210414101047822h");
//        responseHeader.setResponseId(processingIdentifier);
//        recordCommunicationCaseDetailsContent.setResponseHeader(responseHeader);
//        recordCommunicationCaseDetailsResponse.setResponse(recordCommunicationCaseDetailsContent);
//
//
//        RecordCommunicationCaseDetailsResponseData recordCommunicationCaseDetailsResponseData = new RecordCommunicationCaseDetailsResponseData();
//        recordCommunicationCaseDetailsResponseData.setStatus("200");
//        recordCommunicationCaseDetailsResponseData.setMessage("Address Information");
//        recordCommunicationCaseDetailsResponseData.setTimestamp(new Date());
//        recordCommunicationCaseDetailsResponseData.setData(recordCommunicationCaseDetailsResponse);
//        Assertions.assertEquals(new ResponseEntity<>(transformService.getRecordCommunicationCaseDetailsResponse(recordCommunicationCaseDetailsResponse), HttpStatus.OK), result);
//    }
//
//}
