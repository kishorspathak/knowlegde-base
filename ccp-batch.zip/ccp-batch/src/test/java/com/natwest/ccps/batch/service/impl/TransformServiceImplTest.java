//package com.ccp.batch.service.impl;
//
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.serviceparameters.v01.RetrieveContactPreferencesContent;
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.serviceparameters.v01.RetrieveContactPreferencesResponse;
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.transferobjects.v01.ContactPointTO;
//import com.rbsg.soa.c080involvedpartymanagement.contactpreferencemanagement.v03.transferobjects.v01.ContactPreferenceTO;
//import com.rbsg.soa.c080involvedpartymanagement.customerarrangementmanagement.v03.serviceparameters.v01.RetrieveCustomersForArrResponse;
//import com.rbsg.soa.c170communicationmanagement.communicationmanagement.v01.serviceparameters.v01.RecordCommunicationCaseDetailsResponse;
//import com.rbsg.soa.datatypes.primitivedatatypes.v03.AddressComponent;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//
//import java.util.ArrayList;
//import java.util.List;
//
//class TransformServiceImplTest {
//    TransformServiceImpl transformServiceImpl = new TransformServiceImpl();
//
//    @Test
//    void testGetRetrieveContactPreferences() {
//        RetrieveContactPreferencesResponse recordCommunicationCaseDetailsContent = new RetrieveContactPreferencesResponse();
//        RetrieveContactPreferencesContent response = new RetrieveContactPreferencesContent();
//        List<ContactPreferenceTO> contactPreferenceTOS = new ArrayList<>();
//        ContactPreferenceTO contactPreferenceTO = new ContactPreferenceTO();
//        ContactPointTO contactPointTO = new ContactPointTO();
//        List<AddressComponent> hasComponent = new ArrayList<>();
//        AddressComponent addressComponent = new AddressComponent();
//        addressComponent.getAddress().add("JO CASE");
//        addressComponent.setCodeValue("AddresseeLine1");
//        addressComponent.setSchemeName("PostalAddressComponentType");
//        hasComponent.add(addressComponent);
//        contactPointTO.getHasComponent().add(addressComponent);
//        contactPreferenceTO.getContactPoint().add(contactPointTO);
//        contactPreferenceTOS.add(contactPreferenceTO);
//        response.getContactPreferences().add(contactPreferenceTO);
//        recordCommunicationCaseDetailsContent.setResponse(response);
//
//        RetrieveContactPreferencesResponse result = transformServiceImpl.getRetrieveContactPreferences(recordCommunicationCaseDetailsContent);
//
//        Assertions.assertEquals(recordCommunicationCaseDetailsContent, result);
//    }
//
//    @Test
//    void testGetRecordCommunicationCaseDetailsResponse() {
//        RecordCommunicationCaseDetailsResponse result = transformServiceImpl.getRecordCommunicationCaseDetailsResponse(new RecordCommunicationCaseDetailsResponse());
//        Assertions.assertEquals(new RecordCommunicationCaseDetailsResponse(), result);
//    }
//
//    @Test
//    void testGetRetrieveCustomersForArrResponse() {
//        RetrieveCustomersForArrResponse result = transformServiceImpl.getRetrieveCustomersForArrResponse(new RetrieveCustomersForArrResponse());
//        Assertions.assertEquals(new RetrieveCustomersForArrResponse(), result);
//    }
//}
