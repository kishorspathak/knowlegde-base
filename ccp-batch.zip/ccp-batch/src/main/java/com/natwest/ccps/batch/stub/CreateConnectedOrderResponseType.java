package com.natwest.ccps.batch.stub;

import lombok.ToString;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@ToString
public class CreateConnectedOrderResponseType {
    protected String successResponse;
    protected String newExternalOrderId;
    protected String failureResponse;

    public String getSuccessResponse() {
        return successResponse;
    }

    public void setSuccessResponse(String value) {
        this.successResponse = value;
    }


    public String getNewExternalOrderId() {
        return newExternalOrderId;
    }


    public void setNewExternalOrderId(String value) {
        this.newExternalOrderId = value;
    }


    public String getFailureResponse() {
        return failureResponse;
    }


    public void setFailureResponse(String value) {
        this.failureResponse = value;
    }


}
