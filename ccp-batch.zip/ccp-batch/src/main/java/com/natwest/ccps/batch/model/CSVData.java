package com.natwest.ccps.batch.model;

import java.util.List;

public class CSVData {

    private String[] headers;
    private List<String[]> data;

    // Getters and setters
    public String[] getHeaders() {
        return headers;
    }

    public void setHeaders(String[] headers) {
        this.headers = headers;
    }

    public List<String[]> getData() {
        return data;
    }

    public void setData(List<String[]> data) {
        this.data = data;
    }
}