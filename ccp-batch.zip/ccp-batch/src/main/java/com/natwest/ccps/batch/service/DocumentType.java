package com.natwest.ccps.batch.service;

import com.natwest.ccps.batch.model.Document;
import org.springframework.core.io.InputStreamResource;

public interface DocumentType {
    InputStreamResource generateDocuments(Document document);
}