package com.natwest.ccps.batch.service.impl;

import com.natwest.ccps.batch.service.Unique2CpOrderIdGenerator;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
@Service
public class Unique2CpOrderIdGeneratorImpl implements Unique2CpOrderIdGenerator {

    private  final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private  final SecureRandom random = new SecureRandom(); // Secure random generation

    public  String generateUniqueCode() {
        // Start with the prefix "CCP"
        StringBuilder code = new StringBuilder("CCP");

        // Generate the remaining 7 random alphanumeric characters
        for (int i = 0; i < 7; i++) {
            code.append(CHARACTERS.charAt(random.nextInt(CHARACTERS.length())));
        }

        // Ensure the generated code is exactly 10 characters long (it will be by design)
        return code.toString();
    }


}
