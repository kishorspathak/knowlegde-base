package com.natwest.ccps.batch.model;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class JobDetails {
    private String applicationId;
    private String companyId;
    private String applicationVersionId;
}
