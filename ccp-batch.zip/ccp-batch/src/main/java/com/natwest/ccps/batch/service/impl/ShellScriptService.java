package com.natwest.ccps.batch.service.impl;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

@Service
	public class ShellScriptService {
 
		private static final String SCRIPT_PATH = "C:\\Thunderhead\\ccp-batch\\src\\main\\resources\\s3-files-download1.sh";
 
		public void callShellScriptWithFile(String filePath) throws IOException, InterruptedException {
			// Ensure the file exists
			File file = new File(filePath);
			if (!file.exists()) {
				throw new IllegalArgumentException("File not found: " + filePath);
			}
 
			// Build the process
			ProcessBuilder processBuilder = new ProcessBuilder(SCRIPT_PATH, filePath);
			processBuilder.redirectErrorStream(true);
 
			// Start the process
			Process process = processBuilder.start();
 
			// Optionally, read the output from the script
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
				String line;
				while ((line = reader.readLine()) != null) {
					System.out.println(line);
				}
			}
 
			// Wait for the process to finish
			int exitCode = process.waitFor();
			if (exitCode != 0) {
				throw new RuntimeException("Shell script exited with error code: " + exitCode);
			}
		}
	}
