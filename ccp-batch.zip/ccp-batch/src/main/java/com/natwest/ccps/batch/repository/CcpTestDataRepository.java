package com.natwest.ccps.batch.repository;

import com.natwest.ccps.batch.model.CcpTestData;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CcpTestDataRepository extends MongoRepository<CcpTestData, String> {


}
