package com.natwest.ccps.batch.service;

import com.natwest.ccps.batch.model.CcpTestData;
import com.natwest.ccps.batch.model.JobDetails;

import java.util.List;


public interface CsvBatchReaderService {
    public List<String> readCsvFiles();

    void saveData(List<CcpTestData> dataList);

    public JobDetails getApplicationId(String id);
}