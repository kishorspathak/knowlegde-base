package com.natwest.ccps.batch.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.natwest.ccps.batch.clients.SoapClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import java.util.TimeZone;

@Configuration
public class BeanConfig {
    @Autowired
    Environment environment;

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("com.natwest.ccps.batch.stub");
        return marshaller;
    }

    @Bean
    public Jaxb2Marshaller marshaller2() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("com.natwest.ccps.batch.stub");

        return marshaller;
    }


    @Bean
    public SoapClient soapConnector() {
        SoapClient client = new SoapClient();
        //client.setDefaultUri("https://nw222bir.messagepoint.com:443/mp/api/");
        client.setDefaultUri(environment.getProperty("mp.url"));
        client.setMarshaller(marshaller());
        client.setUnmarshaller(marshaller2());
        return client;
    }

  /*  @Bean
    public void setSystemProxy() {
         System.setProperty("proxyHost", environment.getProperty("ccp.proxy.host.val"));
         System.setProperty("proxyPort", environment.getProperty("ccp.proxy.port.val"));
    }*/

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.setTimeZone(TimeZone.getTimeZone("Europe/London"));
        return objectMapper;
    }
}