package com.natwest.ccps.batch.stub;

import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRegistry
public class ObjectFactory {
    public CreateConnectedOrderRequest createCreateConnectedOrderRequest() {
        return new CreateConnectedOrderRequest();
    }
}
