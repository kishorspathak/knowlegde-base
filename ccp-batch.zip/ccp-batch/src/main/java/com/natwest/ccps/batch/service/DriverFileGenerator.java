package com.natwest.ccps.batch.service;

import com.natwest.ccps.batch.model.CcpTestData;
import com.natwest.ccps.batch.model.JobDetails;
import org.springframework.core.io.InputStreamResource;

import java.util.List;

public interface DriverFileGenerator {
    public String generateXml(CcpTestData ccpTestData);
    public String getDataIdByUpdDriverFile(String driverFilePath);

    public JobDetails getApplicationId(String touchPoint);

    public String createJob(JobDetails jobDetails, String dataId);

    public String getTouchpointName();
    public List<String> getResultFieldData(String id);
    public String createOrderRequest(String touchpintGuid, String dataId, String email, String orderId);
    public InputStreamResource downloadFileBasedOnResultsetField(String id);
    public String getVersionIddata(String id);
    public String createOrderRequest1(String orderId);
    public String jobs(String uuid);
    public String getDataIdByUpdDriverFile1(String path);
}
