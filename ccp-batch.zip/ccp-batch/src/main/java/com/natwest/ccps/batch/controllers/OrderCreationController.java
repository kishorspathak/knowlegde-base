package com.natwest.ccps.batch.controllers;

import com.natwest.ccps.batch.model.CSVData;
import com.natwest.ccps.batch.model.Document;
import com.natwest.ccps.batch.model.JobDetails;
import com.natwest.ccps.batch.service.CsvBatchReaderService;
import com.natwest.ccps.batch.service.DocumentType;
import com.natwest.ccps.batch.service.MpCreateOrderService;
import com.natwest.ccps.batch.service.impl.Batch;
import com.natwest.ccps.batch.service.impl.CSVReaderService;
import com.natwest.ccps.batch.service.impl.Interactive;
import com.natwest.ccps.batch.service.impl.OrderGenerator;
import com.natwest.ccps.batch.stub.CreateConnectedOrderResponseType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/ccp/api/batch")
public class OrderCreationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrderCreationController.class);

    private final CSVReaderService csvReaderService;
    private final OrderGenerator orderGenerator;
    @Autowired
    private MpCreateOrderService mpCreateOrderService;
    @Autowired
    @Qualifier("interactive")
    private Interactive interactive;
    @Autowired
    @Qualifier("batch")
    private Batch batch;

    @Autowired
    private CsvBatchReaderService csvBatchReaderService;

    public OrderCreationController(CSVReaderService csvReaderService, OrderGenerator orderGenerator) {
        this.csvReaderService = csvReaderService;
        this.orderGenerator = orderGenerator;
    }

    @PostMapping("/regressionBulkRun")
    public Map runReg(@RequestParam("file") MultipartFile file) {
        LOGGER.info("Received request to generate XML files.");
        Map map = new HashMap();
        Map<String, CSVData> csvDataMap = csvReaderService.readMultipleCSVs(file);
        for (Map.Entry<String, CSVData> entry : csvDataMap.entrySet()) {
            String fileName = entry.getKey();
            CSVData csvData = entry.getValue();
            String[] headers = csvData.getHeaders();
            List<String[]> csvRecords = csvData.getData();
            map.putAll(createOrder(file.getOriginalFilename(), csvRecords, headers));
        }
        LOGGER.info("XML files generated and saved successfully.");
        return map;
    }

    @PostMapping("/createOrder")
    public ResponseEntity<InputStreamResource> runReg1(@RequestBody Document document) {
        LOGGER.info("Received request to generate XML files.", document);
        DocumentType documentType = null;
        if (document != null) {
            switch (document.getDocType()) {
                case "Batch":
                    documentType = batch;
                    break;
                case "interactive":
                    documentType = interactive;
                    break;
            }
            InputStreamResource inputStreamResource = documentType.generateDocuments(document);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+ document.getOrderUuid()+".pdf");
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(inputStreamResource);

        }
        return null;
    }


    private Map createOrder(String fileName, List<String[]> csvRecords, String[] headers) {
        List<CreateConnectedOrderResponseType> createConnectedOrderResponseTypes = new ArrayList<>();
        LOGGER.info("No. of Transaction." + csvRecords.size());
        Map<String, String> map = new HashMap<>();
        for (int i = 0; i < csvRecords.size(); i++) {
            String[] record = csvRecords.get(i);
            String xmlContent = orderGenerator.generateXML(record, headers, new HashMap<>());
            String xmlFileName = fileName.substring(0, fileName.lastIndexOf(".")) + "_" + i + ".xml";
            String xmlFileNameLocation = xmlFileName;
            saveXMLFile(xmlFileNameLocation, xmlContent);
            String dataId = orderGenerator.getDataIdByUpdDriverFile(xmlFileNameLocation);
            map.put(orderGenerator.getExternalId(),
                    orderGenerator.createOrderRequest(orderGenerator.getTouchPointGuid(), orderGenerator.getDataPointsinfo().toString(), dataId, orderGenerator.getExternalId(), orderGenerator.getEmail()));
        }
        return map;
    }

    private void saveXMLFile(String xmlFileName, String xmlContent) {
        try {
            File file = new File(xmlFileName);
            java.io.FileWriter fw = new java.io.FileWriter(file);
            fw.write(xmlContent);
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
            LOGGER.error("Error saving XML file {}: {}", xmlFileName, e.getMessage());
        }
    }


    @GetMapping("/run")
    public List<String> getXlsData() throws IOException {
        return csvBatchReaderService.readCsvFiles();

    }

    @GetMapping("/getApplicationId")
    public JobDetails getApplicationId() throws IOException {
        return csvBatchReaderService.getApplicationId("ZZ_AMT-Test");

    }

    @GetMapping("/test")
    public String test() throws IOException {
        return "Test";

    }

}