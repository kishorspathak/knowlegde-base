package com.natwest.ccps.batch.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.ccps.batch.constant.Constant;
import com.natwest.ccps.batch.stub.ConnectedOrderDataPointType;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Getter
@Service
@Scope("prototype")
@Slf4j
public class OrderGenerator {
    private String touchPointGuid;


    private String email;
    private String externalId;
    @Autowired
    private Environment environment;

    private List<ConnectedOrderDataPointType> dataPoints;


    private StringBuilder dataPointsinfo;

    public String generateXML(String[] rowData, String[] headers, HashMap hashMap) {
        StringBuilder xmlBuilder = new StringBuilder("<DriverFile>");
        List<String> list = getTeamDetails();
        dataPoints = new ArrayList<>();
        dataPointsinfo = new StringBuilder();
        ConnectedOrderDataPointType connectedOrderDataPointType = null;
        for (int i = 0; i < rowData.length; i++) {
            String value = rowData[i];
            if (i <= 10) {
                extracted(headers, xmlBuilder, i, value);
                continue;
            } else if (i <= 15) {
                if (i == 11)
                    xmlBuilder.append("<CCPTemplateDB>");
                extracted(headers, xmlBuilder, i, value);
                if (i == 15) {
                    xmlBuilder.append("</CCPTemplateDB>");
                    xmlBuilder.append("<CCPTeamDB>");
                }

            } else {
                if (headers[i] != null && list.contains(headers[i].replace(" ", "")))
                    extracted(headers, xmlBuilder, i, value);
                else {
                    if (StringUtils.isNotEmpty(value) & (!headers[i].equalsIgnoreCase("email"))) {
                        dataPointsinfo.append("<sch:DataPoint><sch:Connector>" + headers[i] + "</sch:Connector><sch:Value>" + value + "</sch:Value></sch:DataPoint>");

                    } else if (headers[i].equalsIgnoreCase("email")) {
                        this.email = value;
                    }
                    connectedOrderDataPointType = new ConnectedOrderDataPointType();
                    connectedOrderDataPointType.setConnector(headers[i]);
                    connectedOrderDataPointType.setConnector(value);
                    dataPoints.add(connectedOrderDataPointType);
                }

            }
        }
        xmlBuilder.append("</CCPTeamDB>");
        xmlBuilder.append("</DriverFile>");
        return xmlBuilder.toString();
    }

    private void extracted(String[] headers, StringBuilder xmlBuilder, int i, String value) {
        if (value != null && !value.isEmpty()) {
            if (headers[i].equalsIgnoreCase("OrderUuid")) {
                this.externalId = value;
            }
            if (headers[i].equalsIgnoreCase("TouchpointGUID")) {
                this.touchPointGuid = value;
            }
            if (headers[i].equalsIgnoreCase("email")) {
                this.email = value;
            }
            xmlBuilder.append("<").append(headers[i]).append(">").append(value).append("</").append(headers[i]).append(">");
        }
    }

    public String getDataIdByUpdDriverFile(String path) {
        try {
            log.info("path::: " + path);
            File file = new File(path);
            byte[] fileContent = Files.readAllBytes(file.toPath());
            String payload = new String(fileContent);

            URL obj = new URL(environment.getProperty("mppm.url") + File.separator + "files");
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
           /* if (BooleanUtils.toBoolean(environment.getProperty("mppm.cloud"))) {
                InetSocketAddress proxyInet = new InetSocketAddress(environment.getProperty("ccp.proxy.host.val"),
                        Integer.parseInt(environment.getProperty("ccp.proxy.port.val")));
                Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyInet);
                con = (HttpURLConnection) obj.openConnection(proxy);
            } else {
                con = (HttpURLConnection) obj.openConnection();
            }*/
            con.setRequestMethod("POST");
            con.setRequestProperty("pinc-file-name", file.getName());
            con.setRequestProperty("Content-Type", "application/xml");
            con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setDoOutput(true);
            log.info("pinc-company-id :: " + environment.getProperty("mppm.pinc-company-id"));
            log.info("authorization :: " + environment.getProperty("mppm.pinc.auth"));
            log.info("HttpURLConnection :: " + con);
            log.info("mppm url :: " + environment.getProperty("mppm.url") + File.separator + "files");
            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                wr.writeBytes(payload);
                wr.flush();
            }
            int responseCode = con.getResponseCode();
            System.out.println("Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            log.info("Driver-File-Upload-process Response :: " + response);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response.toString());

            String dataId = jsonNode.get("id").asText();
            System.out.println(response);
            log.info("Data ID: " + dataId);
            deleteDriverFile(new File(path));
            return dataId;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed while uploading Driver file on MP, Error :: " + e.getMessage());

        }
    }

    public String createOrderRequest(String touchpintGuid, String datapoints, String dataId, String orderId, String email) {
        String xml = Constant.CREATE_ORDER_REQUEST;
        xml = xml.replace("$mp.username", Objects.requireNonNull(environment.getProperty("mp.username"))).
                replace("$mp.password", Objects.requireNonNull(environment.getProperty("mp.password"))).
                replace("$mp.branch", Objects.requireNonNull(environment.getProperty("mp.branch"))).
                replace("$mp.node.id", Objects.requireNonNull(environment.getProperty("mp.node.id"))).
                replace("$mp.pre.release", Objects.requireNonNull(environment.getProperty("mp.pre.release"))).
                replace("$touchpintGuid", touchpintGuid).
                replace("$dataPointList", datapoints).replace("$dataID", dataId).replace("$uuid", orderId).
                replace("$email", email);
        String requestData = xml;
        log.info("MP Request create order:: " + requestData);


        return callSoapService(requestData, orderId).replace("\"", "");
    }

    public String createOrderRequest1(String touchpintGuid, String dataId, String email,String orderId) {
        String xml = Constant.CREATE_ORDER_REQUEST;
        xml = xml.replace("$mp.username", Objects.requireNonNull(environment.getProperty("mp.username"))).
                replace("$mp.password", Objects.requireNonNull(environment.getProperty("mp.password"))).
                replace("$mp.branch", Objects.requireNonNull(environment.getProperty("mp.branch"))).
                replace("$mp.node.id", Objects.requireNonNull(environment.getProperty("mp.node.id"))).
                replace("$mp.pre.release", Objects.requireNonNull(environment.getProperty("mp.pre.release"))).
                replace("$touchpintGuid", touchpintGuid).
                replace("$email", email);
        String requestData = xml;
        log.info("MP Request create order:: " + requestData);


        return callSoapService(requestData, orderId).replace("\"", "");
    }

    private String callSoapService(String soapRequest, String orderId) {
        try {
            URL obj = new URL(environment.getProperty("mp.url"));
            HttpURLConnection con = null;
            /*if (BooleanUtils.toBoolean(String.valueOf(environment.getProperty("env.name")).equalsIgnoreCase("sit"))) {
                InetSocketAddress proxyInet = new InetSocketAddress(environment.getProperty("ccp.proxy.host.val"), Integer.parseInt(environment.getProperty("ccp.proxy.port.val")));
                Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyInet);
                con = (HttpURLConnection) obj.openConnection(proxy);
            } else {*/
            con = (HttpURLConnection) obj.openConnection();
            // }

            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type", "text/xml;charset=utf-8");
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(soapRequest);
            wr.flush();
            wr.close();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            String finalvalue = response.toString();
            log.info("Create order response :: " + finalvalue);
            ObjectMapper objectMapper = new ObjectMapper();
            String resInJson = objectMapper.writeValueAsString(new com.fasterxml.jackson.dataformat.xml.XmlMapper().readTree(finalvalue));
            log.info("Create order  resInJson  :: " + resInJson);
            resInJson = resInJson.replace("\\", "");
            resInJson.replace("\\", "");
           /* if (StringUtils.isNotEmpty(resInJson) && resInJson.contains("\"count\":\"1\"")) {
                resInJson = resInJson.replace("\"Touchpoint\":{\"Name\"", "\"Touchpoint\":[{\"Name\"");
                resInJson = resInJson.replace("}}}}}}", "}}]}}}}");
            }*/
            if (resInJson.contains("SuccessResponse") && orderId != null) {
                resInJson = resInJson + ", URL : https://recp-2cp-dev-pm-files.s3.eu-west-1.amazonaws.com/2CPLTRS_" + orderId + ".pdf";
            }
            return resInJson;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean deleteDriverFile(File file) {
        if (file != null) {
            return file.delete();
        }
        return false;
    }

    private List<String> getTeamDetails() {
        ArrayList<String> centreData = new ArrayList<String>();

// Add the elements to the ArrayList
        centreData.add("CentreName");
        centreData.add("TeamName");
        centreData.add("CentreAddLine1");
        centreData.add("CentreAddLine2");
        centreData.add("CentreAddLine3");
        centreData.add("CentreAddLine4");
        centreData.add("CentreAddLine5");
        centreData.add("CentrePostCode");
        centreData.add("PhonenumberRBS");
        centreData.add("PhonenumberNWB");
        centreData.add("PhonenumberUBN");
        centreData.add("LotCodeRbs");
        centreData.add("LotCodeNwb");
        centreData.add("LotCodeUbn");
        centreData.add("OverseasPhoneNumberRbs");
        centreData.add("OverseasPhoneNumberNwb");
        centreData.add("OverseasPhoneNumberUbn");
        centreData.add("BreCode");
        centreData.add("BreDescription");
        centreData.add("Signatory");
        centreData.add("SignatoryJobTitle");
        centreData.add("SignatoryRacfId");
        return centreData;
    }

    public StringBuilder getDataPointsinfo() {
        return dataPointsinfo;
    }

    public String getEmail() {
        return email;
    }

}