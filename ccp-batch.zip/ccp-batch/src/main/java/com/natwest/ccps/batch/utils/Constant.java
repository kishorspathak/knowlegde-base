package com.natwest.ccps.batch.utils;

public class Constant {
    public static final String SORT_CODE_LENGTH = "Sort code must contains 6 digits";
    public static final String ACCOUNT_NO_LENGTH = "Account no must contains 8 digits";
    public static final String SORT_CODE_NUMERIC = "Sort code must be Numeric";
    public static final String ACCOUNT_NO_NUMERIC = "Account no must be Numeric";
    public static final String RESOURCE = "Resource not found";
    public static final String ADDRESS_NOT_FOUND = "Address not found";

}
