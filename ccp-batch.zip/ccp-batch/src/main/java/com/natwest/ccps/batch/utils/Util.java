package com.natwest.ccps.batch.utils;

import org.apache.commons.lang3.text.WordUtils;

import java.util.*;

public class Util {

    /*
     * The addressee name and address line components (but not the postcode) need to be converted from
     * Upper Case to Dual Case using the following rules:
     * IF the first 2 characters are "O'" (capital O followed by an apostrophe) THEN the third
     * character is uppercase (e.g. O'DONOVAN becomes O'Donovan) OR
     * • IF the first 2 characters are "MC" THEN the third character is uppercase (e.g. MCBRIDE
     * becomes McBride) OR
     * • IF the first 3 characters are "MAC" AND the 4th character is NOT "H" THEN the 4th character
     * is uppercase (e.g. MACDONALD becomes MacDonald, BUT MACHIN becomes Machin)
     *
     */
    public static String applyCapitalizeRule(String address) {
        List<String> addressList = new ArrayList<>(Arrays.asList(address.split(" ")));
        StringBuilder stringBuilder = new StringBuilder();
        for (String name : addressList) {
            if (name.startsWith("O'")) {
                stringBuilder.append(WordUtils.capitalize(name.toLowerCase(Locale.ROOT), new char[]{'\''}));
            } else if (name.startsWith("MC")) {
                stringBuilder.append(WordUtils.capitalize(name.toLowerCase(Locale.ROOT), new char[]{'c'}));
            } else if (name.length() >= 3 && name.startsWith("MAC")) {
                if (name.charAt(3) != 'H' || name.charAt(3) != 'h')
                    stringBuilder.append(WordUtils.capitalize(name.toLowerCase(Locale.ROOT), new char[]{'c'}));
                else
                    stringBuilder.append(WordUtils.capitalize(name.toLowerCase(Locale.ROOT), null));
            } else {
                stringBuilder.append(WordUtils.capitalize(name.toLowerCase(Locale.ROOT), null));
            }
            stringBuilder.append(" ");
        }

        String hh = stringBuilder.toString().trim();

        return hh;
    }

    public static String removeSpace(String postCode) {
        return postCode.trim().replaceAll(" +", " ");
    }

    public static String hexValue(String postCode) {
        return postCode.replaceAll("&", "66");
    }

    /*special characters (<  > & " ') we need to escape these
    special characters with (&lt;  &gt;  &amp;  &quot;  &apos;)*/
    public static String specialCharacter(String value) {
       /* char[] values = value.toCharArray();
        value = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");*/
        return value;
    }

    public static String getSalutation(String addr1, String addr2) {
        if (addr1 == null) {
            addr1 = "";
        }

        if (addr2 == null) {
            addr2 = "";
        }

        addr1 = addr1.trim();
        addr2 = addr2.trim();
        String addAnd = "";
        String whitespace = " ";
        String addr1LC = addr1.toLowerCase();
        String addr2LC = addr2.toLowerCase();
        if (!addr1LC.endsWith(" &") && !addr1LC.endsWith(" and") && (addr1LC.contains(" & ") || addr1LC.contains(" and "))) {
            int posSymbolAnd = addr1LC.indexOf(" & ");
            int posWordAnd = addr1LC.indexOf(" and ");
            if (posSymbolAnd > -1 || posWordAnd > -1) {
                int lenSymbolAnd = " & ".length();
                int lenWordAnd = " and ".length();
                if (posWordAnd != -1 && (posSymbolAnd == -1 || posSymbolAnd >= posWordAnd)) {
                    addr2LC = addr1LC.substring(posWordAnd + lenWordAnd);
                    addr1LC = addr1LC.substring(0, posWordAnd + 1);
                } else {
                    addr2LC = addr1LC.substring(posSymbolAnd + lenSymbolAnd);
                    addr1LC = addr1LC.substring(0, posSymbolAnd + 1);
                }
            }
        }

        addr1LC = addr1LC.trim();
        addr2LC = addr2LC.trim();
        if (!"".equals(addr1LC) && !"".equals(addr2LC)) {
            addAnd = " and ";
        }

        if (addr1LC.contains("esq")) {
            addr1LC = addr1LC.replace("esq", "");
        }

        if (addr2LC.contains("esq")) {
            addr2LC = addr2LC.replace("esq", "");
        }

        if (addr1LC.endsWith(" &")) {
            addr1LC = addr1LC.substring(0, addr1LC.length() - "&".length()) + "and";
        }

        if (addr2LC.startsWith("& ")) {
            addr2LC = "and " + addr2LC.substring("&".length() + 1);
        }

        if (addr1LC.endsWith(" and")) {
            addr1LC = addr1LC.substring(0, addr1LC.length() - " and".length());
        }

        if (addr2LC.startsWith("and ")) {
            addr2LC = addr2LC.substring("and".length() + 1);
        }

        String[] addr1Arr = addr1LC.split(whitespace);
        String[] addr2Arr = addr2LC.split(whitespace);
        if (addr1Arr.length == 1 && addr2Arr.length > 1) {
            return convertCase(true, addr1Arr[0] + addAnd + addr2Arr[0] + whitespace + addr2Arr[addr2Arr.length - 1]);
        } else if (addr2Arr.length == 1 && addr1Arr.length > 1) {
            return convertCase(true, addr1Arr[0] + whitespace + addr1Arr[addr1Arr.length - 1] + addAnd + addr2Arr[0]);
        } else if (addr1Arr.length == 1 && addr2Arr.length == 1) {
            return convertCase(true, addr1Arr[0] + addAnd + addr2Arr[0]);
        } else if (addr1Arr[0].equalsIgnoreCase(addr2Arr[0]) && addr1Arr[addr1Arr.length - 1].equalsIgnoreCase(addr2Arr[addr2Arr.length - 1])) {
            return convertCase(true, addr1LC + addAnd + addr2LC);
        } else {
            return !addr1Arr[0].equalsIgnoreCase(addr2Arr[0]) && addr1Arr[addr1Arr.length - 1].equalsIgnoreCase(addr2Arr[addr2Arr.length - 1]) ? convertCase(true, addr1Arr[0] + whitespace + addr1Arr[addr1Arr.length - 1] + addAnd + addr2Arr[0] + whitespace + addr2Arr[addr2Arr.length - 1]) : convertCase(true, addr1Arr[0] + whitespace + addr1Arr[addr1Arr.length - 1] + addAnd + addr2Arr[0] + whitespace + addr2Arr[addr2Arr.length - 1]);
        }
    }

    public static String convertCase(boolean isSalutation, String str) {
        if (str == null) {
            return "";
        } else {
            StringBuffer sb = new StringBuffer();
            str = str.toLowerCase();
            StringTokenizer strTitleCase = new StringTokenizer(str);

            while(true) {
                while(strTitleCase.hasMoreTokens()) {
                    String s = strTitleCase.nextToken();
                    if (isSalutation && s.equalsIgnoreCase("and")) {
                        sb.append(s + " ");
                    } else {
                        sb.append(s.replaceFirst(s.substring(0, 1), s.substring(0, 1).toUpperCase()) + " ");
                    }
                }

                String m_lookfor = "O'";
                String m_value = sb.toString();
                m_value = m_value.trim();
                if (m_value.contains(m_lookfor) && (m_value.indexOf(m_lookfor) == 0 || m_value.charAt(m_value.indexOf(m_lookfor) - 1) == ' ')) {
                    m_value = upperChar(m_value, m_lookfor, m_lookfor.length());
                }

                m_lookfor = "Mc";
                if (m_value.contains(m_lookfor) && (m_value.indexOf(m_lookfor) == 0 || m_value.charAt(m_value.indexOf(m_lookfor) - 1) == ' ')) {
                    m_value = upperChar(m_value, m_lookfor, m_lookfor.length());
                }

                m_lookfor = "Mac";
                if (m_value.contains(m_lookfor)) {
                    char m_char = m_value.charAt(m_value.indexOf(m_lookfor) + 3);
                    if (m_char != ' ' && m_char != 'h' && (m_value.indexOf(m_lookfor) == 0 || m_value.charAt(m_value.indexOf(m_lookfor) - 1) == ' ')) {
                        m_value = upperChar(m_value, m_lookfor, m_lookfor.length());
                    }
                }

                int indexOfHyphen = m_value.indexOf("-");
                if (indexOfHyphen != -1) {
                    StringBuffer sbHyphen = new StringBuffer();
                    StringTokenizer strToken = new StringTokenizer(m_value, "-");

                    while(strToken.hasMoreTokens()) {
                        String sTemp = strToken.nextToken();
                        sbHyphen.append(sTemp.replaceFirst(sTemp.substring(0, 1), sTemp.substring(0, 1).toUpperCase()) + "-");
                    }

                    if (sbHyphen.charAt(sbHyphen.length() - 1) == '-') {
                        sbHyphen = new StringBuffer(sbHyphen.substring(0, sbHyphen.length() - 1));
                    }

                    m_value = sbHyphen.toString();
                }

                return m_value;
            }
        }
    }

    private static String upperChar(String m_value, String lookfor, int index) {
        String v1 = m_value.substring(0, m_value.indexOf(lookfor) + index);
        m_value = v1 + Character.toUpperCase(m_value.charAt(m_value.indexOf(lookfor) + index)) + m_value.substring(m_value.indexOf(lookfor) + index + 1);
        return m_value;
    }


}
