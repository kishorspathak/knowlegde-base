package com.natwest.ccps.batch.service.impl;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

public class S3ToGithub {

    private static final String BUCKET_NAME = "recp-2cp-dev-pm-files"; // Change the bucket accordingly
    private static final Regions CLIENT_REGION = Regions.EU_WEST_1;

    // AWS credentials (Hardcoded for demonstration purposes; not recommended for production)
    private static final String AWS_ACCESS_KEY_ID = "AKIA5JZYGV6ZINOUY7UC";
    private static final String AWS_SECRET_ACCESS_KEY = "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";

    public static void main(String[] args) {

        if (args.length != 1) {
            System.err.println("Please provide the source file as an argument.");
            System.exit(1);
        }

        String sourceFile = args[0];

        // Ensure the input file exists
        if (!Files.exists(Paths.get(sourceFile))) {
            System.err.println("File not found: " + sourceFile + ", Kindly pass the file as argument");
            System.exit(1);
        }

        // Create a directory with the current date
        String directory = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        File dir = new File(directory);

        if (!dir.exists()) {
            if (dir.mkdir()) {
                System.out.println("Directory '" + directory + "' created");
            } else {
                System.err.println("Failed to create directory: " + directory);
                System.exit(1);
            }
        } else {
            System.out.println("Directory '" + directory + "' already exists");
        }

        // Initialize S3 client with hardcoded credentials
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY);
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                .withRegion(CLIENT_REGION)
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .build();

        // Read the list of URLs from the user-passed text file
        try (BufferedReader reader = new BufferedReader(new FileReader(sourceFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);

                // Extract the S3 object file name from the URL
                String s3FileName = line.substring(line.lastIndexOf('/') + 1);
                System.out.println("Object file name: " + s3FileName);

                // Download files to local
                try {
                    S3Object s3Object = s3Client.getObject(new GetObjectRequest(BUCKET_NAME, s3FileName));
                    InputStream inputStream = s3Object.getObjectContent();
                    File localFile = new File(dir, s3FileName);

                    try (FileOutputStream outputStream = new FileOutputStream(localFile)) {
                        byte[] buffer = new byte[1024];
                        int bytesRead;
                        while ((bytesRead = inputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, bytesRead);
                        }
                        System.out.println("File " + s3FileName + " downloaded to local successfully");
                    }
                } catch (AmazonServiceException e) {
                    System.err.println("Failed to download: s3://" + BUCKET_NAME + "/" + s3FileName);
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}