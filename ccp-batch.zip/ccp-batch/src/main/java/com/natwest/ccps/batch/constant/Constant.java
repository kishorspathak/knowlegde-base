package com.natwest.ccps.batch.constant;

public class Constant {

    public static String CREATE_ORDER_REQUEST = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sch=\"http://messagepoint.com/api/schemas\">" +
            "   <soapenv:Header>" +
            "      <wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">" +
            "         <wsse:UsernameToken wsu:Id=\"\">" +
            "            <wsse:Username>$mp.username</wsse:Username>" +
            "            <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">$mp.password</wsse:Password>" +
            "         </wsse:UsernameToken>" +
            "      </wsse:Security>" +
            "   </soapenv:Header>" +
            "   <soapenv:Body>" +
            "      <sch:CreateConnectedOrderRequest>" +
            "         <sch:BranchId>$mp.branch</sch:BranchId>" +
            "  <sch:CreateProof>true</sch:CreateProof> " +
            "  <sch:NewExternalOrderId>$uuid</sch:NewExternalOrderId> " +
            "         <sch:NodeId>$mp.node.id</sch:NodeId> " +
            "         <sch:Prerelease>$mp.pre.release</sch:Prerelease> " +
            " <sch:Touchpoint> " +
            "                <sch:Guid>$touchpintGuid</sch:Guid>\n" +
            "            </sch:Touchpoint>" +
            "<sch:AuthorUsername>$email</sch:AuthorUsername>"+
            "<sch:AutoApprove>true</sch:AutoApprove>"+
            "         <sch:DataPointList>" +
            "<sch:DataPoint><sch:Connector>dataId</sch:Connector><sch:Value>$dataID</sch:Value></sch:DataPoint><sch:DataPoint><sch:Connector>UUID</sch:Connector><sch:Value>$uuid</sch:Value></sch:DataPoint> " +
            "$dataPointList</sch:DataPointList>" +
            "      </sch:CreateConnectedOrderRequest>" +
            "   </soapenv:Body>" +
            "</soapenv:Envelope>";
    public static String CREATE_ORDER_REQUEST1 = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sch=\"http://messagepoint.com/api/schemas\">" +
            "   <soapenv:Header>" +
            "      <wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">" +
            "         <wsse:UsernameToken wsu:Id=\"\">" +
            "            <wsse:Username>$mp.username</wsse:Username>" +
            "            <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">$mp.password</wsse:Password>" +
            "         </wsse:UsernameToken>" +
            "      </wsse:Security>" +
            "   </soapenv:Header>" +
            "   <soapenv:Body>" +
            "      <sch:CreateConnectedOrderRequest>" +
            "         <sch:BranchId>$mp.branch</sch:BranchId>" +
            "  <sch:CreateProof>true</sch:CreateProof> " +
            "  <sch:NewExternalOrderId>$uuid</sch:NewExternalOrderId> " +
            "         <sch:NodeId>$mp.node.id</sch:NodeId> " +
            "         <sch:Prerelease>$mp.pre.release</sch:Prerelease> " +
            " <sch:Touchpoint> " +
            "                <sch:Guid>$touchpintGuid</sch:Guid>\n" +
            "            </sch:Touchpoint>" +
            "<sch:AuthorUsername>$email</sch:AuthorUsername>"+
            "<sch:AutoApprove>true</sch:AutoApprove>"+
            "         <sch:DataPointList>" +
            "<sch:DataPoint><sch:Connector>dataId</sch:Connector><sch:Value>$dataID</sch:Value></sch:DataPoint> " +
            "</sch:DataPointList>" +
            "      </sch:CreateConnectedOrderRequest>" +
            "   </soapenv:Body>" +
            "</soapenv:Envelope>";
    public static String request ="<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sch=\"http://messagepoint.com/api/schemas\">\n" +
            "<soapenv:Header>\n" +
            "<wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
            "<wsse:UsernameToken wsu:Id=\"\">\n" +
            "<wsse:Username>NWB-2CP-Users</wsse:Username>\n" +
            "<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#Password\">TmF0d2VzdEAxMjM0</wsse:Password>\n" +
            "</wsse:UsernameToken>\n" +
            "</wsse:Security>\n" +
            "</soapenv:Header>\n" +
            "<soapenv:Body>\n" +
            "    <ReleaseForApprovalOrActivateConnectedOrderRequest xmlns=\"http://messagepoint.com/api/schemas\">\n" +
            "      <BranchId>$mp.branch</BranchId>\n" +
            "      <NodeId>$mp.node.id</NodeId>\n" +
            "      <Prerelease>false</Prerelease>\n" +
            "      <ExternalOrderId>$uuid</ExternalOrderId>\n" +
            "    </ReleaseForApprovalOrActivateConnectedOrderRequest>\n" +
            "  </soapenv:Body>\n" +
            "</soapenv:Envelope>";
}
