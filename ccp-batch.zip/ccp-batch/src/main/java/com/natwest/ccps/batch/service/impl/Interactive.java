package com.natwest.ccps.batch.service.impl;


import com.natwest.ccps.batch.model.Document;
import com.natwest.ccps.batch.model.JobDetails;
import com.natwest.ccps.batch.service.DocumentType;
import com.natwest.ccps.batch.service.DriverFileGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service("interactive")
@Slf4j
public
class Interactive implements DocumentType {

    @Autowired
    private OrderGenerator orderGenerator;
    @Autowired
    private DriverFileGenerator driverFileGenerator;

    @Override
    public InputStreamResource generateDocuments(Document document) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = "output_" + timestamp + ".xml";
        // Get the classpath directory and create the file
        File file = saveXMLFile(fileName, document.getDocumentContent());
        String dataId = driverFileGenerator.getDataIdByUpdDriverFile(file.getName());
        // driverFileGenerator.createOrderRequest(document.getTouchPointGuid(), dataId, document.getEmail(), document.getOrderUuid());
        JobDetails jobDetails = driverFileGenerator.getApplicationId(document.getTouchpointName());
        String versionId = driverFileGenerator.getVersionIddata(jobDetails.getApplicationId());
        jobDetails.setApplicationVersionId(versionId);
        String response = driverFileGenerator.createJob(jobDetails, dataId);
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        List<String> resultSetFields = driverFileGenerator.getResultFieldData(response);
        if (resultSetFields == null || resultSetFields.size() == 0) {
            log.error("ResultFieldId is empty", resultSetFields);
            return null;
        }

        return driverFileGenerator.downloadFileBasedOnResultsetField(resultSetFields.get(0));
       /*
        //driverFileGenerator.getPDFbyJobId(response);
        List<String> resultSetFields = driverFileGenerator.getResultFieldData("45b4fc87*//* for (String id : resultSetFields) {
            return driverFileGenerator.downloadFileBasedOnResultsetField();
        }*//*-0ffe-433a-a1d8-f96a353ce6fc");

        String id = resultSetFields.get(1);*/
        // return driverFileGenerator.downloadFileBasedOnResultsetField("3a14c4ae-1a3a-4e98-8a88-14357397a89c");
    }

    private File saveXMLFile(String xmlFileName, String xmlContent) {
        File file = null;
        try {
            file = new File(xmlFileName);
            java.io.FileWriter fw = new java.io.FileWriter(file);
            fw.write(xmlContent);
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
            // LOGGER.error("Error saving XML file {}: {}", xmlFileName, e.getMessage());
        }
        return file;
    }
}