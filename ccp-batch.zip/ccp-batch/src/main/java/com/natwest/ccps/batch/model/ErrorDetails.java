package com.natwest.ccps.batch.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@XmlRootElement
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorDetails {
    int code;
    Date timestamp;
    String message;
    String details;
}
