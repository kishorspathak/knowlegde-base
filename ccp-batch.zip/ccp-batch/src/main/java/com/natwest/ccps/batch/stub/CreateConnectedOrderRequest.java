package com.natwest.ccps.batch.stub;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CreateConnectedOrderRequest {
    protected TouchpointType touchpoint;
    protected String authorUsername;
    protected ConnectedOrderDataPointListType dataPointList;
    protected String newExternalOrderId;
    protected String tagCloud;
    protected Boolean createProof;
    protected String email;
    protected Boolean autoApprove;
    protected String branchId;
    protected String nodeId;
    protected String prerelease;


    public String getBranchId() {
        return branchId;
    }


    public void setBranchId(String value) {
        this.branchId = value;
    }


    public String getNodeId() {
        return nodeId;
    }


    public void setNodeId(String value) {
        this.nodeId = value;
    }


    public String getPrerelease() {
        return prerelease;
    }


    public void setPrerelease(String value) {
        this.prerelease = value;
    }


    public TouchpointType getTouchpoint() {
        return touchpoint;
    }


    public void setTouchpoint(TouchpointType value) {
        this.touchpoint = value;
    }


    public String getAuthorUsername() {
        return authorUsername;
    }

    public void setAuthorUsername(String value) {
        this.authorUsername = value;
    }


    public ConnectedOrderDataPointListType getDataPointList() {
        return dataPointList;
    }


    public void setDataPointList(ConnectedOrderDataPointListType value) {
        this.dataPointList = value;
    }


    public String getNewExternalOrderId() {
        return newExternalOrderId;
    }


    public void setNewExternalOrderId(String value) {
        this.newExternalOrderId = value;
    }


    public String getTagCloud() {
        return tagCloud;
    }


    public void setTagCloud(String value) {
        this.tagCloud = value;
    }


    public Boolean isCreateProof() {
        return createProof;
    }

    public void setCreateProof(Boolean value) {
        this.createProof = value;
    }


    public String getEmail() {
        return email;
    }


    public void setEmail(String value) {
        this.email = value;
    }


    public Boolean isAutoApprove() {
        return autoApprove;
    }


    public void setAutoApprove(Boolean value) {
        this.autoApprove = value;
    }

}
