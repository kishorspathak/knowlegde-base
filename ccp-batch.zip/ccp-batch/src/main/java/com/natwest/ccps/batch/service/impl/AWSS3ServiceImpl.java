package com.natwest.ccps.batch.service.impl;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class AWSS3ServiceImpl  {

    private static final Logger LOGGER = LoggerFactory.getLogger(AWSS3ServiceImpl.class);

    @Autowired
    private AmazonS3 amazonS3;
    @Value("${aws.s3.bucket}")
    private String bucketName;

    @Async
    public void deleteFile(final String fileName) {
        String finalFileName = fileName.replace(bucketName+ "/", "");
        String jsonFileName = finalFileName.replace("2CPLTRS_", "");
        // Prepare List of files to be deleted from S3 Bucket
        List<String> fileKeys = new ArrayList<>();

        fileKeys.add(finalFileName +".pdf");
        fileKeys.add(finalFileName +".vpf");
        fileKeys.add(finalFileName +".vpf.ind");
        fileKeys.add(jsonFileName  + "_RF.json");

        for(String fileKey: fileKeys){
            final DeleteObjectRequest deleteObjectRequest = new DeleteObjectRequest(bucketName, fileKey);
            LOGGER.info("S3 File to be deleted : " + bucketName + " :: " + fileKey);
            amazonS3.deleteObject(deleteObjectRequest);
            LOGGER.info("S3 File : " + fileKey + " deleted successfully.");
        }



    }

    @Async
    public void download( String fileName) {
        S3Object s3Object = amazonS3.getObject(bucketName,"2CPLTRS_B000009906.pdf");
        System.out.println(s3Object);
        InputStream inputStream =s3Object.getObjectContent();
        File file = new File("nikhil.pdf");
       try( FileOutputStream fileOutputStream = new FileOutputStream(file)) {
           byte[] read_buf = new byte[1024];
           int read_len;
           while((read_len=inputStream.read(read_buf))>0){
               fileOutputStream.write(read_buf,0,read_len);
           }
       } catch (IOException e) {
           e.printStackTrace();
       }
    }
}
