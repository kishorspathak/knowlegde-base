package com.natwest.ccps.batch.service;

public interface Unique2CpOrderIdGenerator {

    public String generateUniqueCode();
}
