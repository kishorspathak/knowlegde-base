package com.natwest.ccps.batch.exceptions;

import com.natwest.ccps.batch.model.ErrorDetails;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Date;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = {ResourceNotFoundException.class})
    public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException ex, WebRequest webRequest) {
        ErrorDetails errorDetails = new ErrorDetails(400, new Date(), ex.getLocalizedMessage(), webRequest.getDescription(false));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .contentType(MediaType.valueOf(MediaType.APPLICATION_XML_VALUE))
                .body(errorDetails);
    }
/*
    @ExceptionHandler(GlobalException.class)
    public ResponseEntity<Object> handleExceptions(GlobalException exception, WebRequest webRequest) {
        RetrieveContactPreferencesResponseData retrieveContactPreferencesResponseData = new RetrieveContactPreferencesResponseData();
        retrieveContactPreferencesResponseData.setTimestamp(new Date());
        retrieveContactPreferencesResponseData.setMessage(exception.getLocalizedMessage());
        retrieveContactPreferencesResponseData.setStatus(exception.getStatusCode());
        retrieveContactPreferencesResponseData.setUrl(webRequest.getDescription(false));
        retrieveContactPreferencesResponseData.setData(exception.getRetrieveContactPreferencesResponseData().getData());
        ResponseEntity<Object> entity = new ResponseEntity<>(retrieveContactPreferencesResponseData, HttpStatus.NOT_FOUND);
        return entity;
    }*/

}
