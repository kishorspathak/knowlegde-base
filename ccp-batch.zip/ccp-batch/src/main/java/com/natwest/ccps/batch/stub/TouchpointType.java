package com.natwest.ccps.batch.stub;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TouchpointType {
    private String guid;

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getGuid() {
        return guid;
    }
}
