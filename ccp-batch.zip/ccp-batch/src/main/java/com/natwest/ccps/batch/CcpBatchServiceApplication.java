package com.natwest.ccps.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CcpBatchServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(CcpBatchServiceApplication.class, args);
	}
}
