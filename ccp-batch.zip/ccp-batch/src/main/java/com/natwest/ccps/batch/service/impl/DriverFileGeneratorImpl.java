package com.natwest.ccps.batch.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.ccps.batch.constant.Constant;
import com.natwest.ccps.batch.model.CcpTestData;
import com.natwest.ccps.batch.model.JobDetails;
import com.natwest.ccps.batch.service.DriverFileGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.annotation.PostConstruct;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class DriverFileGeneratorImpl implements DriverFileGenerator {
    @Value("${driver.files.path}")
    private String driverFilePath;
    @Autowired
    private Environment environment;

    private String touchpointName;
    @Value("${document.environment.name}")
    private String environmentName;

    @PostConstruct
    public void init() {
        File file = new File(System.getProperty("user.dir") + File.separator + driverFilePath);
        if (!file.exists()) file.mkdir();
    }

    public String generateXml(CcpTestData ccpTestData) {
        try {
            // log.info("Generating Driver file ::" + ccpTestData.getRef());
            // Create XML document
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            // Root element
            Element driverFile = doc.createElement("DriverFile");
            driverFile.setAttribute("xmlns:xsi", "https://natwest.com/XMLSchema-instance");
            doc.appendChild(driverFile);

            // Add elements to DriverFile
            createElement(doc, driverFile, "RecordKey", "development");
            createElement(doc, driverFile, "OrderUuid", ccpTestData.getRef());
            createElement(doc, driverFile, "EnvironmentIdentifier", "development");
            createElement(doc, driverFile, "PRODUCT_NAME", "2CPLTRS");
            createElement(doc, driverFile, "Mailclass", "2");
            createElement(doc, driverFile, "CinOrBin", "");
            createElement(doc, driverFile, "Cin2", "");
            createElement(doc, driverFile, "EDeliveryOnly", "N");
            createElement(doc, driverFile, "PartyID", "");
            createElement(doc, driverFile, "PaperlessIndicator", "P");
            createElement(doc, driverFile, "CustomerType", "");

            Element ccpTemplateDB = doc.createElement("CCPTemplateDB");
            driverFile.appendChild(ccpTemplateDB);

            // Create Customer element

            createElement(doc, ccpTemplateDB, "TouchpointName", "x-Test");
            createElement(doc, ccpTemplateDB, "TouchpointGUID", "");
            createElement(doc, ccpTemplateDB, "TemplateID", "ABCXYZ001");
            createElement(doc, ccpTemplateDB, "BusinessArea", "Retail banking");
            createElement(doc, ccpTemplateDB, "AddressFormatInd", "");
            Element customer = doc.createElement("Customer");
            driverFile.appendChild(customer);
            // Populate Customer element with ccpTestData values
            createElement(doc, customer, "TEMPLATE_COMMON_NAME", ccpTestData.getTemplateCommonName());
            createElement(doc, customer, "Brand", ccpTestData.getBrand());
            createElement(doc, customer, "MAILING_REF", ccpTestData.getMailingRef());
            createElement(doc, customer, "TEMPLATE_COMMON_NAME", ccpTestData.getTemplateCommonName());
            createElement(doc, customer, "Brand", ccpTestData.getBrand());
            createElement(doc, customer, "MAILING_REF", ccpTestData.getMailingRef());
            createElement(doc, customer, "REF", ccpTestData.getRef());
            createElement(doc, customer, "Title", ccpTestData.getTitle());
            createElement(doc, customer, "First_Names", ccpTestData.getFirstNames());
            createElement(doc, customer, "Surname", ccpTestData.getSurname());
            createElement(doc, customer, "Address_Line_1", ccpTestData.getAddressLine1());
            createElement(doc, customer, "Address_Line_2", ccpTestData.getAddressLine2());
            createElement(doc, customer, "Address_Line_3", ccpTestData.getAddressLine3());
            createElement(doc, customer, "Address_Line_4", ccpTestData.getAddressLine4());
            createElement(doc, customer, "Address_Line_5", ccpTestData.getAddressLine5());
            createElement(doc, customer, "Postcode", ccpTestData.getPostcode());
            createElement(doc, customer, "Country_Name", ccpTestData.getCountryName());
            createElement(doc, customer, "CIN", ccpTestData.getCin());
            createElement(doc, customer, "Provider_Name", ccpTestData.getProviderName());
            createElement(doc, customer, "Product_Name", ccpTestData.getProductName());
            createElement(doc, customer, "Date_Product_Was_Sold", ccpTestData.getDateProductWasSold());
            createElement(doc, customer, "Date_Product_Was_Bought", ccpTestData.getDateProductWasBought());
            createElement(doc, customer, "Total_Payment_Value", ccpTestData.getTotalPaymentValue());
            createElement(doc, customer, "Payment_Lieu", ccpTestData.getPaymentLieu());
            createElement(doc, customer, "Tax_Deducted", ccpTestData.getTaxDeducted());
            createElement(doc, customer, "Account_Ending", ccpTestData.getAccountEnding());
            createElement(doc, customer, "Calculation_Date", ccpTestData.getCalculationDate());
            createElement(doc, customer, "Initial_Investment", ccpTestData.getInitialInvestment());
            createElement(doc, customer, "Current_Value", ccpTestData.getCurrentValue());
            createElement(doc, customer, "Nominal_Value", ccpTestData.getNominalValue());
            createElement(doc, customer, "Difference", ccpTestData.getDifference());
            createElement(doc, customer, "Letter_Post_Date", ccpTestData.getLetterPostDate());
            createElement(doc, customer, "PRODUCT_CLOSED_DATE", ccpTestData.getProductClosedDate());
            createElement(doc, customer, "TOTAL_PAYMENT", ccpTestData.getTotalPayment());
            createElement(doc, customer, "WITHDRAWAL_VALUE", ccpTestData.getWithdrawalValue());
            createElement(doc, customer, "RATIONALE", ccpTestData.getRationale());
            createElement(doc, customer, "ME_SUITABILITY_FAILURE_REASON", ccpTestData.getMeSuitabilityFailureReason());
            createElement(doc, customer, "BENCHMARK", ccpTestData.getBenchmark());
            createElement(doc, customer, "CLOSED_VALUE", ccpTestData.getClosedValue());
            createElement(doc, customer, "PRODUCT_PROVIDER", ccpTestData.getProductProvider());
            createElement(doc, customer, "ALTERNATIVE_PRODUCT_OR_FUND_COMPARISON", ccpTestData.getAlternativeProductOrFundComparison());
            createElement(doc, customer, "AMOUNT_ABOVE_BENCHMARK", ccpTestData.getAmountAboveBenchmark());
            createElement(doc, customer, "SUITABILITY", ccpTestData.getSuitability());
            createElement(doc, customer, "Date_Of_Letter", ccpTestData.getDateOfLetter());
            createElement(doc, customer, "DATE_OF_LETTER_90_DAYS", ccpTestData.getDateOfLetter90Days());
            createElement(doc, customer, "SIGNATURE", ccpTestData.getSignature());
            createElement(doc, customer, "SIGNED_DATE", ccpTestData.getSignedDate());
            createElement(doc, customer, "DATE_OF_LAST_LETTER_SENT", ccpTestData.getDateOfLastLetterSent());
            // Add other elements

            // Write the content into an XML file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            // Naming the XML file based on REF value
            String refValue = ccpTestData.getRef();
            // String fileName = refValue != null ? refValue + ".xml" : "output.xml";
            String projectDirectory = System.getProperty("user.dir");
            String absoluteFilePath = Paths.get(projectDirectory, driverFilePath, ccpTestData.getRef() + ".xml").toString();
            StreamResult result = new StreamResult(new File(absoluteFilePath));

            transformer.transform(source, result);
            setTouchpointName("ZZ_AMT-Test");
            log.info("DriverFile with ref. number " + ccpTestData.getRef() + " file created successfully!");
            return absoluteFilePath;
        } catch (ParserConfigurationException | TransformerException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void createElement(Document doc, Element parent, String tagName, String value) {
        Element element = doc.createElement(tagName);
        element.appendChild(doc.createTextNode(value != null ? value : ""));
        parent.appendChild(element);
    }

    @Override
    public String getDataIdByUpdDriverFile(String path) {
        try {
            //  log.info("path::: " + path);
            File file = new File(path);
            byte[] fileContent = Files.readAllBytes(file.toPath());
            String payload = new String(fileContent);

            URL obj = new URL(environment.getProperty("mppm.url") + File.separator + "files");
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            con.setRequestMethod("POST");
            con.setRequestProperty("pinc-file-name", file.getName());
            con.setRequestProperty("Content-Type", "application/xml");
            con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setRequestProperty("pinc-environment", "test");
            con.setDoOutput(true);
            // log.info("pinc-company-id :: " + environment.getProperty("mppm.pinc-company-id"));
            //log.info("authorization :: " + environment.getProperty("mppm.pinc.auth"));
            //log.info("HttpURLConnection :: " + con);
            log.info("mppm url :: " + environment.getProperty("mppm.url") + File.separator + "files");
            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                wr.writeBytes(payload);
                wr.flush();
            }
            int responseCode = con.getResponseCode();
            System.out.println("Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            //log.info("Driver-File-Upload-process Response :: " + response);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response.toString());

            String dataId = jsonNode.get("id").asText();
            //System.out.println(response);
            log.info("Data ID: " + dataId);

            return dataId;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed while uploading Driver file on MP, Error :: " + e.getMessage());

        }
    }
    @Override
    public String getDataIdByUpdDriverFile1(String path) {
        try {
            //  log.info("path::: " + path);
            File file = new File(path);
            byte[] fileContent = Files.readAllBytes(file.toPath());
            String payload = new String(fileContent);

            URL obj = new URL(environment.getProperty("mppm.url") + File.separator + "files");
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            con.setRequestMethod("POST");
            con.setRequestProperty("pinc-file-name", file.getName());
            con.setRequestProperty("Content-Type", "application/xml");
            con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setRequestProperty("pinc-environment", "production");
            con.setDoOutput(true);
            log.info("production");
            // log.info("pinc-company-id :: " + environment.getProperty("mppm.pinc-company-id"));
            //log.info("authorization :: " + environment.getProperty("mppm.pinc.auth"));
            //log.info("HttpURLConnection :: " + con);
            log.info("mppm url :: " + environment.getProperty("mppm.url") + File.separator + "files");
            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                wr.writeBytes(payload);
                wr.flush();
            }
            int responseCode = con.getResponseCode();
            System.out.println("Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            //log.info("Driver-File-Upload-process Response :: " + response);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response.toString());

            String dataId = jsonNode.get("id").asText();
            //System.out.println(response);
            log.info("Data ID: " + dataId);

            return dataId;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed while uploading Driver file on MP, Error :: " + e.getMessage());

        }
    }

    public JobDetails getApplicationId(String touchpointName) {
        try {
            //touchpointName="THR_CB AML002-Master Exits Letter_POC";
            //touchpointName="THR_CQ005-Holding Letter Day 15";
            log.info("touchpointName::: " + touchpointName);

            UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl("https://mp.ccpdev.shared.banksvcs.net/api/v1/applications")
                    .queryParam("metadata.mpdc.touchpoint.name", touchpointName);
            URL obj = new URL(uriComponentsBuilder.toUriString());

            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            //System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
            //con.setRequestProperty("Content-Type", "application/xml");
            //con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setRequestProperty("Host", "mp.ccpdev.shared.banksvcs.net");


            // con.setRequestProperty("metadata.mpdc.touchpoint.name", touchpointName);
            con.setDoOutput(true);
            //log.info("authorization :: " + environment.getProperty("mppm.pinc.auth"));
            //log.info("HttpURLConnection :: " + con);

            int responseCode = con.getResponseCode();
            System.out.println("Application id Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            setTouchpointName(touchpointName);
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            log.info("Retrieving-ApplicationId-process Response :: " + response);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response.toString());
            log.info("Response ::::: " + response);
            JobDetails jobDetails = new JobDetails();
            for (JsonNode jsonObject : jsonNode) {
                jobDetails.setApplicationId(jsonObject.get("id").asText());
                jobDetails.setApplicationVersionId(jsonObject.get("productionVersionId").asText());
                jobDetails.setCompanyId(jsonObject.get("companyId").asText());
            }

            //System.out.println(response);
            log.info("JobDetails: " + jobDetails);

            return jobDetails;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed while uploading Driver file on MP, Error :: " + e.getMessage());

        }
    }

    public String createJob(JobDetails jobDetails, String dataId) {
        try {
            log.info("Job details :: ", jobDetails);
            log.info("dataId ::" + dataId);

            UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl("https://mp.ccpdev.shared.banksvcs.net/api/v1/jobs");
            URL obj = new URL(uriComponentsBuilder.toUriString());

            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            //System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
            con.setRequestProperty("Content-Type", "application/json");
            //con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setRequestProperty("Host", "mp.ccpdev.shared.banksvcs.net");
            con.setDoOutput(true);
            String requestBody = "{\n" +
                    "    \"applicationId\": \"" + jobDetails.getApplicationId() + "\"," +
                    "    \"companyId\": \"" + jobDetails.getCompanyId() + "\"," +
                    //    "    \"environment\": \"" + environmentName + "\"," +
                    "    \"applicationVersionId\": \"" + jobDetails.getApplicationVersionId() + "\"," +
                    /* "    \"name\": \""+touchpointName + String.valueOf(System.currentTimeMillis() ).substring(0,10)+"\", \"driverFileIds\": [" +*/
                    "    \"name\": \"" + touchpointName + "\", \"driverFileIds\": [" +
                    "        \"" + dataId + "\"" +
                    "    ]" +
                    "}";
            log.info("Request Body ::" + requestBody);
            OutputStream outputStream = con.getOutputStream();
            outputStream.write(requestBody.getBytes());
            outputStream.flush();
            outputStream.close();
            // con.setRequestProperty("metadata.mpdc.touchpoint.name", touchpointName);

            //log.info("authorization :: " + environment.getProperty("mppm.pinc.auth"));
            //log.info("HttpURLConnection :: " + con);

            int responseCode = con.getResponseCode();
            System.out.println("Application id Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            log.info("Response create job :: " + response);
            //log.info("Retrieving-ApplicationId-process Response :: " + response);
            /*ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response.toString());
            String applicationId = null;
            for (JsonNode jsonObject : jsonNode) {
                applicationId = jsonObject.get("id").asText();
            }

            //System.out.println(response);
            log.info("Application ID: " + applicationId);*/
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response.toString());
            String idValue = jsonNode.get("id").asText();
            log.info("idValue_createjob :: ->" + idValue);

            return idValue;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed while uploading Driver file on MP, Error :: " + e.getMessage());

        }
    }

    public String jobs(String uuid) {
        try {

            UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl("https://mp.ccpdev.shared.banksvcs.net/api/v1/jobs");
            URL obj = new URL(uriComponentsBuilder.toUriString());

            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            //System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
            con.setRequestProperty("Content-Type", "application/json");
            //con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setRequestProperty("Host", "mp.ccpdev.shared.banksvcs.net");
            con.setDoOutput(true);

            // con.setRequestProperty("metadata.mpdc.touchpoint.name", touchpointName);

            //log.info("authorization :: " + environment.getProperty("mppm.pinc.auth"));
            //log.info("HttpURLConnection :: " + con);

            int responseCode = con.getResponseCode();
            System.out.println("jobs : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            log.info("Response create job :: " + response);
           /* ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(response.toString());
            String idValue = jsonNode.get("id").asText();
            log.info("idValue_createjob :: ->" + idValue);*/
            ObjectMapper objectMapper = new ObjectMapper();

            // Parse the JSON input into a list of maps
            List<Map<String, Object>> jobs = objectMapper.readValue(response.toString(), new TypeReference<List<Map<String, Object>>>() {
            });

            // Loop through the jobs and search for the name
            String toSearch = "connected-production-" + uuid;
            log.info("toSearch ::" + toSearch);
            for (Map<String, Object> job : jobs) {
                if (job.containsKey("name") && job.get("name").equals(toSearch)) {

                    log.info("id found ::" + job.get("id").toString());
                    return job.get("id").toString(); // Return the ID if the name matches
                }
            }
            log.error("No id is found for string " + toSearch);
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed while uploading Driver file on MP, Error :: " + e.getMessage());

        }
    }


    public String getTouchpointName() {
        return touchpointName;
    }

    public void setTouchpointName(String touchpointName) {
        this.touchpointName = touchpointName;
    }

    public List<String> getResultFieldData(String id) {
        StringBuilder responseContent = null;
        String urlSpec = environment.getProperty("mppm.url") + File.separator + "jobs" + File.separator + id;
        try {

            URL endpoint = new URL(urlSpec);
            HttpURLConnection con = (HttpURLConnection) endpoint.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setDoOutput(true);

            int responseCode = con.getResponseCode();
            log.info("Response Code: " + responseCode + " urlSpec::" + urlSpec);

            // Read and print response content
            responseContent = new StringBuilder();
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = con.getInputStream().read(buffer)) != -1) {
                responseContent.append(new String(buffer, 0, bytesRead));
            }
            log.info("Response Content::::::: " + responseContent);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(String.valueOf(responseContent));


            // Fetching resultFileIds
            JsonNode resultFileIdsNode = jsonNode.path("resultFileIds");
            List<String> resultFileIds = new ArrayList<>();

            if (resultFileIdsNode.isArray()) {
                for (JsonNode idNode : resultFileIdsNode) {
                    resultFileIds.add(idNode.asText());
                }
            }

            con.disconnect();
            return resultFileIds;
        } catch (IOException e) {
            log.error("Failed while executing " + environment.getProperty("mppm.url") + File.separator + "jobs" + File.separator + id);
            e.printStackTrace();
        }
        return null;
    }

    public String getVersionIddata(String id) {
        StringBuilder responseContent = null;
        String urlSpec = environment.getProperty("mppm.url") + File.separator + "applications" + File.separator + id + File.separator + "versions";
        try {

            URL endpoint = new URL(urlSpec);
            HttpURLConnection con = (HttpURLConnection) endpoint.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));
            con.setDoOutput(true);

            int responseCode = con.getResponseCode();
            log.info("Response Code: " + responseCode + " urlSpec::" + urlSpec);

            // Read and print response content
            responseContent = new StringBuilder();
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = con.getInputStream().read(buffer)) != -1) {
                responseContent.append(new String(buffer, 0, bytesRead));
            }
            log.info("Response Content:::::::version " + responseContent);

            try {
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode rootNode = objectMapper.readTree(responseContent.toString());

                // Fetch the "id" of the first element
                String _id = rootNode.get(0).get("id").asText();
                System.out.println("First element id: " + _id);
                return _id;
            } catch (IOException e) {
                e.printStackTrace();
            }
            con.disconnect();
            return null;
        } catch (IOException e) {
            log.error("Failed while executing " + environment.getProperty("mppm.url") + File.separator + "applications" + File.separator + id);
            e.printStackTrace();
        }
        return null;
    }

    public InputStreamResource downloadFileBasedOnResultsetField(String id) {
        StringBuilder responseContent = null;
        String urlSpec = environment.getProperty("mppm.url") + File.separator + "files" + File.separator + id + "?download=true";
        try {

            URL endpoint = new URL(urlSpec);
            HttpURLConnection con = (HttpURLConnection) endpoint.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("pinc-company-id", environment.getProperty("mppm.pinc-company-id"));
            con.setRequestProperty("authorization", environment.getProperty("mppm.pinc.auth"));

            int responseCode = con.getResponseCode();
            log.info("Response Code: " + responseCode + " urlSpec::" + urlSpec);
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = con.getInputStream();
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }

                byte[] fileData = outputStream.toByteArray();
                if (fileData.length == 0) {
                    log.error("File is empty");
                }
                InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(fileData));
                return resource;
            } else {
                return null;
            }
        } catch (IOException e) {
            log.error("Failed while executing " + environment.getProperty("mppm.url") + File.separator + "jobs" + File.separator + id);
            e.printStackTrace();
        }
        return null;
    }

    public String createOrderRequest(String touchpintGuid, String dataId, String email, String orderId) {
        String xml = Constant.CREATE_ORDER_REQUEST1;
        xml = xml.replace("$mp.username", Objects.requireNonNull(environment.getProperty("mp.username"))).
                replace("$mp.password", Objects.requireNonNull(environment.getProperty("mp.password"))).
                replace("$mp.branch", Objects.requireNonNull(environment.getProperty("mp.branch"))).
                replace("$mp.node.id", Objects.requireNonNull(environment.getProperty("mp.node.id"))).
                replace("$mp.pre.release", Objects.requireNonNull(environment.getProperty("mp.pre.release"))).
                replace("$touchpintGuid", touchpintGuid).
                replace("$dataID", dataId).
                replace("$email", email).
                replace("$uuid", orderId);
        String requestData = xml;
        log.info("MP Request create order:: " + requestData);


        return callSoapService(requestData, orderId);
    }

    public String createOrderRequest1(String orderId) {
        String xml = Constant.request;
        xml = xml.replace("$mp.username", Objects.requireNonNull(environment.getProperty("mp.username"))).
                replace("$mp.password", Objects.requireNonNull(environment.getProperty("mp.password"))).
                replace("$mp.branch", Objects.requireNonNull(environment.getProperty("mp.branch"))).
                replace("$mp.node.id", Objects.requireNonNull(environment.getProperty("mp.node.id"))).
                replace("$mp.pre.release", Objects.requireNonNull(environment.getProperty("mp.pre.release"))).
                replace("$uuid", orderId);
        String requestData = xml;
        log.info("MP Request create order:: " + requestData);


        return callSoapService(requestData, orderId);
    }

    private String callSoapService(String soapRequest, String orderId) {
        try {
            URL obj = new URL(environment.getProperty("mp.url"));
            HttpURLConnection con = null;
            /*if (BooleanUtils.toBoolean(String.valueOf(environment.getProperty("env.name")).equalsIgnoreCase("sit"))) {
                InetSocketAddress proxyInet = new InetSocketAddress(environment.getProperty("ccp.proxy.host.val"), Integer.parseInt(environment.getProperty("ccp.proxy.port.val")));
                Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyInet);
                con = (HttpURLConnection) obj.openConnection(proxy);
            } else {*/
            con = (HttpURLConnection) obj.openConnection();
            // }

            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type", "text/xml;charset=utf-8");
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(soapRequest);
            wr.flush();
            wr.close();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            String finalvalue = response.toString();
            log.info("Create order response :: " + finalvalue);
            ObjectMapper objectMapper = new ObjectMapper();
            String resInJson = objectMapper.writeValueAsString(new com.fasterxml.jackson.dataformat.xml.XmlMapper().readTree(finalvalue));
            log.info("Create order  resInJson  :: " + resInJson);
            resInJson = resInJson.replace("\\", "");
            resInJson.replace("\\", "");
           /* if (StringUtils.isNotEmpty(resInJson) && resInJson.contains("\"count\":\"1\"")) {
                resInJson = resInJson.replace("\"Touchpoint\":{\"Name\"", "\"Touchpoint\":[{\"Name\"");
                resInJson = resInJson.replace("}}}}}}", "}}]}}}}");
            }*/
            if (resInJson.contains("SuccessResponse") && orderId != null) {
                resInJson = resInJson + ", URL : https://recp-2cp-dev-pm-files.s3.eu-west-1.amazonaws.com/2CPLTRS_" + orderId + ".pdf";
            }
            return resInJson;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private String callSoapService1(String soapRequest, String orderId) {
        try {
            URL obj = new URL(environment.getProperty("mp.url"));
            HttpURLConnection con = null;
            /*if (BooleanUtils.toBoolean(String.valueOf(environment.getProperty("env.name")).equalsIgnoreCase("sit"))) {
                InetSocketAddress proxyInet = new InetSocketAddress(environment.getProperty("ccp.proxy.host.val"), Integer.parseInt(environment.getProperty("ccp.proxy.port.val")));
                Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyInet);
                con = (HttpURLConnection) obj.openConnection(proxy);
            } else {*/
            con = (HttpURLConnection) obj.openConnection();
            // }

            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type", "text/xml;charset=utf-8");
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(soapRequest);
            wr.flush();
            wr.close();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            String finalvalue = response.toString();
            log.info("Create order response :: " + finalvalue);
            ObjectMapper objectMapper = new ObjectMapper();
            String resInJson = objectMapper.writeValueAsString(new com.fasterxml.jackson.dataformat.xml.XmlMapper().readTree(finalvalue));
            log.info("Create order  resInJson  :: " + resInJson);
            resInJson = resInJson.replace("\\", "");
            String id = new ObjectMapper().readTree(resInJson).path("Body").
                    path("ReleaseForApprovalOrActivateConnectedOrderResponse").path("SuccessResponse").asText().replaceAll(".*id = (\\S+).*", "$1");

            return id;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}