package com.natwest.ccps.batch.controllers;

import com.natwest.ccps.batch.service.impl.ShellScriptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequestMapping("/ccp/api/batch/test")
	public class ShellScriptController {
 
		@Autowired
		private ShellScriptService shellScriptService;
 
		@GetMapping("/run-script")
		public String runScript() {
			try {
				System.out.println("Running...");
				shellScriptService.callShellScriptWithFile("C:\\dev\\Programs\\terraformtest\\sourceurl1.txt");
				return "Script executed successfully!";
			} catch (IOException | InterruptedException e) {
				return "Error executing script: " + e.getMessage();
			}
		}
	}