package com.natwest.ccps.batch.model;

import lombok.Data;
import lombok.ToString;

import java.io.File;
import java.util.Date;
@Data
@ToString
public class Document {
    String extSysId;
    String extDocId;
    String intDocId;
    String docBusinessArea;
    String docType;
    String docName;
    String documentContent;
    Boolean isArchivalNeeded;
    Boolean isOmnichannelDoc;
    Boolean isOnlyEmailDoc;
    Boolean isOnlyPrintDoc;
    Boolean isOnlySmsDoc;
    File driverFile;
    Date creationDate;
    String touchpointName;
    String touchPointGuid;
    String orderUuid;
    String email;
}