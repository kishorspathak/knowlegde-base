package com.natwest.ccps.batch.service;

import com.natwest.ccps.batch.stub.ConnectedOrderDataPointType;
import com.natwest.ccps.batch.stub.CreateConnectedOrderRequest;
import com.natwest.ccps.batch.stub.CreateConnectedOrderResponseType;

import java.util.List;

public interface MpCreateOrderService {

    public CreateConnectedOrderRequest createConnectedOrderRequest(String externalId, String dataId, String touchpointGuid, List<ConnectedOrderDataPointType> dataPoints);

    public CreateConnectedOrderResponseType createOrder(CreateConnectedOrderRequest connectedOrderRequest, String externalOrderId);



}
