package com.natwest.ccps.batch.stub;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;
@XmlRootElement
public class ConnectedOrderDataPointListType {
    protected List<ConnectedOrderDataPointType> dataPoint;

    public List<ConnectedOrderDataPointType> getDataPoint() {
        if (dataPoint == null) {
            dataPoint = new ArrayList<ConnectedOrderDataPointType>();
        }
        return this.dataPoint;
    }

}
