package com.natwest.ccps.batch.stub;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ConnectedOrderDataPointType {
    protected String connector;
    protected String value;

    public String getConnector() {
        return connector;
    }

    public void setConnector(String value) {
        this.connector = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
