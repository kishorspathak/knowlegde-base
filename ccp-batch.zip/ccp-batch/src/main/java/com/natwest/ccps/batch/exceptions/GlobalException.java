package com.natwest.ccps.batch.exceptions;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
@Data
@NoArgsConstructor
public class GlobalException extends RuntimeException {
    private String statusCode;

    public GlobalException(String exception, String statusCode) {
        super(exception);
        this.statusCode = statusCode;
    }
}