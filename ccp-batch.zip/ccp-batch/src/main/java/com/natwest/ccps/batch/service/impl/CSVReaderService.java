package com.natwest.ccps.batch.service.impl;

import com.natwest.ccps.batch.model.CSVData;
import com.opencsv.CSVReader;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CSVReaderService {


    public Map<String, CSVData> readMultipleCSVs(MultipartFile file) {
        Map<String, CSVData> csvDataMap = new HashMap<>();
        try {
            CSVData csvData = readCSV(file);
            synchronized (csvDataMap) {
                csvDataMap.put(file.getName(), csvData);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return csvDataMap;
    }

    private CSVData readCSV(MultipartFile file) throws Exception {
        CSVData csvData = new CSVData();
        try (Reader reader1 = new InputStreamReader(file.getInputStream())) {
            CSVReader reader = new CSVReader(reader1);
            // Read headers
            String[] headers = reader.readNext();
            // Read data rows
            List<String[]> records = new ArrayList<>();
            String[] record;
            while ((record = reader.readNext()) != null) {
                records.add(record);
            }
            csvData.setHeaders(headers);
            csvData.setData(records);
            reader.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return csvData;
    }
}