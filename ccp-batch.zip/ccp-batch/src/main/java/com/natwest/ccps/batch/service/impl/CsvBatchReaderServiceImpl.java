package com.natwest.ccps.batch.service.impl;

import com.natwest.ccps.batch.model.CcpTestData;
import com.natwest.ccps.batch.model.JobDetails;
import com.natwest.ccps.batch.repository.CcpTestDataRepository;
import com.natwest.ccps.batch.service.CsvBatchReaderService;
import com.natwest.ccps.batch.service.DriverFileGenerator;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class CsvBatchReaderServiceImpl implements CsvBatchReaderService {
    @Autowired
    private CcpTestDataRepository ccpTestDataRepository;
    @Autowired
    private DriverFileGenerator driverFileGenerator;

    @Value("${csv.files.path}")
    private String csvFilesPath;

    public List<String> readCsvFiles() {
        List<CcpTestData> dataList = new ArrayList<>();
        String response = null;
        File directory = new File(csvFilesPath);
        File[] files = directory.listFiles((dir, name) -> name.toLowerCase().endsWith(".csv"));
        List<String> resList = new ArrayList<>();
        if (files != null) {
            for (File file : files) {
                try (CSVReader reader = new CSVReader(new FileReader(file))) {
                    String[] headers = reader.readNext(); // Read header row

                    // Read data rows
                    String[] nextLine;
                    while ((nextLine = reader.readNext()) != null) {
                        CcpTestData data = new CcpTestData();
                        for (int i = 0; i < headers.length; i++) {
                            setField(data, headers[i], nextLine[i]);
                        }
                        dataList.add(data);
                        String driverFilepath = driverFileGenerator.generateXml(data);
                        // log.info("Driver file created at : - " + driverFilepath);
                        String dataId = null;
                        String applicationId = null;
                        if (driverFilepath != null) {
                            //  log.info("Uploading Driver file :: " + driverFilepath);
                            dataId = driverFileGenerator.getDataIdByUpdDriverFile(driverFilepath);
                            log.info("Data -id " + dataId);
                            //  log.info("Retrieving application id through touchpoint name :  ");
                            JobDetails jobDetails = driverFileGenerator.getApplicationId(driverFileGenerator.getTouchpointName());
                            response = driverFileGenerator.createJob(jobDetails, dataId);
                            resList.add(response);

                        }


                    }
                } catch (CsvValidationException | FileNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        return resList;
    }

    @Override
    public void saveData(List<CcpTestData> dataList) {
        ccpTestDataRepository.saveAll(dataList);
    }

    @Override
    public JobDetails getApplicationId(String id) {
        return driverFileGenerator.getApplicationId(id);
    }

    private void setField(CcpTestData data, String header, String value) {
        switch (header) {
            case "TEMPLATE_COMMON_NAME":
                data.setTemplateCommonName(value);
                break;
            case "Brand":
                data.setBrand(value);
                break;
            case "MAILING_REF":
                data.setMailingRef(value);
                break;
            case "REF":
                data.setRef(value);
                break;
            case "Title":
                data.setTitle(value);
                break;
            case "First_Names":
                data.setFirstNames(value);
                break;
            case "Surname":
                data.setSurname(value);
                break;
            case "Address_Line_1":
                data.setAddressLine1(value);
                break;
            case "Address_Line_2":
                data.setAddressLine2(value);
                break;
            case "Address_Line_3":
                data.setAddressLine3(value);
                break;
            case "Address_Line_4":
                data.setAddressLine4(value);
                break;
            case "Address_Line_5":
                data.setAddressLine5(value);
                break;
            case "Postcode":
                data.setPostcode(value);
                break;
            case "Country_Name":
                data.setCountryName(value);
                break;
            case "CIN":
                data.setCin(value);
                break;
            case "Provider_Name":
                data.setProviderName(value);
                break;
            case "Product_Name":
                data.setProductName(value);
                break;
            case "Date_Product_Was_Sold":
                data.setDateProductWasSold(value);
                break;
            case "Date_Product_Was_Bought":
                data.setDateProductWasBought(value);
                break;
            case "Total_Payment_Value":
                data.setTotalPaymentValue(value);
                break;
            case "Payment_Lieu":
                data.setPaymentLieu(value);
                break;
            case "Tax_Deducted":
                data.setTaxDeducted(value);
                break;
            case "Account_Ending":
                data.setAccountEnding(value);
                break;
            case "Calculation_Date":
                data.setCalculationDate(value);
                break;
            case "Initial_Investment":
                data.setInitialInvestment(value);
                break;
            case "Current_Value":
                data.setCurrentValue(value);
                break;
            case "Nominal_Value":
                data.setNominalValue(value);
                break;
            case "Difference":
                data.setDifference(value);
                break;
            case "Letter_Post_Date":
                data.setLetterPostDate(value);
                break;
            case "PRODUCT_CLOSED_DATE":
                data.setProductClosedDate(value);
                break;
            case "TOTAL_PAYMENT":
                data.setTotalPayment(value);
                break;
            case "WITHDRAWAL_VALUE":
                data.setWithdrawalValue(value);
                break;
            case "RATIONALE":
                data.setRationale(value);
                break;
            case "ME_SUITABILITY_FAILURE_REASON":
                data.setMeSuitabilityFailureReason(value);
                break;
            case "BENCHMARK":
                data.setBenchmark(value);
                break;
            case "CLOSED_VALUE":
                data.setClosedValue(value);
                break;
            case "PRODUCT_PROVIDER":
                data.setProductProvider(value);
                break;
            case "ALTERNATIVE_PRODUCT_OR_FUND_COMPARISON":
                data.setAlternativeProductOrFundComparison(value);
                break;
            case "AMOUNT_ABOVE_BENCHMARK":
                data.setAmountAboveBenchmark(value);
                break;
            case "SUITABILITY":
                data.setSuitability(value);
                break;
            case "Date_Of_Letter":
                data.setDateOfLetter(value);
                break;
            case "DATE_OF_LETTER_90_DAYS":
                data.setDateOfLetter90Days(value);
                break;
            case "DATE_OF_LETTER_30_DAYS":
                data.setDateOfLetter30Days(value);
                break;
            case "SIGNATURE":
                data.setSignature(value);
                break;
            case "SIGNED_DATE":
                data.setSignedDate(value);
                break;
            case "DATE_OF_LAST_LETTER_SENT":
                data.setDateOfLastLetterSent(value);
                break;
            case "DATE_OFFER_LETTER_30_DAYS":
                data.setDateOfferLetter30Days(value);
                break;
            case "DATE_OFFER_LETTER_90_DAYS":
                data.setDateOfferLetter90Days(value);
                break;
            case "TOTAL_REFUND_VALUE":
                data.setTotalRefundValue(value);
                break;
            // Add cases for other fields
        }
    }
}