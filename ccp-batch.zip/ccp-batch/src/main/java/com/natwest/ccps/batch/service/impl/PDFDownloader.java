package com.natwest.ccps.batch.service.impl;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class PDFDownloader {

    private static final int CONNECTION_TIMEOUT = 10000; // 10 seconds
    private static final int READ_TIMEOUT = 15000; // 15 seconds

    public static void downloadPDF(String urlString, String outputPath) {
        InputStream inputStream = null;
        FileOutputStream outputStream = null;
        HttpURLConnection urlConnection = null;

        try {
            URL url = new URL(urlString);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setConnectTimeout(CONNECTION_TIMEOUT);
            urlConnection.setReadTimeout(READ_TIMEOUT);
            urlConnection.setInstanceFollowRedirects(true); // Follow redirects

            // Set User-Agent to mimic a browser
            urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.61 Safari/537.36");
            urlConnection.setRequestProperty("Host", "recp-2cp-dev-pm-files.s3.eu-west-1.amazonaws.com");
            urlConnection.setRequestProperty("Upgrade-Insecure-Requests", "1");

            // Check the response code
            int responseCode = urlConnection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                System.out.println("Failed to download file: " + urlString + " - Response code: " + responseCode);
                return;
            }

            // Get the input stream
            inputStream = new BufferedInputStream(urlConnection.getInputStream());

            // Create the output stream
            outputStream = new FileOutputStream(outputPath);

            // Read bytes from the URL and write them to the output file
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            System.out.println("Successfully downloaded: " + urlString);

        } catch (MalformedURLException e) {
            System.out.println("Invalid URL: " + urlString + " - " + e.getMessage());
        } catch (SocketTimeoutException e) {
            System.out.println("Timeout error while downloading file: " + urlString + " - " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error downloading file: " + urlString + " - " + e.getMessage());
        } finally {
            try {
                if (inputStream != null) inputStream.close();
                if (outputStream != null) outputStream.close();
                if (urlConnection != null) urlConnection.disconnect();
            } catch (IOException e) {
                System.out.println("Error closing streams: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        // List of URLs to download PDFs from
        List<String> pdfUrls = new ArrayList<>();
        pdfUrls.add("https://recp-2cp-dev-pm-files.s3.eu-west-1.amazonaws.com/2CPLTRS_B000011114.pdf");

        // Download each PDF
        for (int i = 0; i < pdfUrls.size(); i++) {
            String url = pdfUrls.get(i);
            String outputPath = "downloaded_file_" + (i + 1) + ".pdf";
            downloadPDF(url, outputPath);
        }
    }
}