package com.natwest.ccps.batch.service.impl;


import com.natwest.ccps.batch.model.Document;
import com.natwest.ccps.batch.service.DocumentType;
import com.natwest.ccps.batch.service.DriverFileGenerator;
import com.natwest.ccps.batch.service.Unique2CpOrderIdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service("batch")
@Slf4j
public class Batch implements DocumentType {
    @Autowired
    Unique2CpOrderIdGenerator unique2CpOrderIdGenerator;

    @Autowired
    private DriverFileGenerator driverFileGenerator;

    @Override
    public InputStreamResource generateDocuments(Document document) {
        //document.setOrderUuid(unique2CpOrderIdGenerator.generateUniqueCode());
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = "output_" + timestamp + ".xml";
        // Get the classpath directory and create the file
        File file = saveXMLFile(fileName, document.getDocumentContent());
        String dataId = driverFileGenerator.getDataIdByUpdDriverFile1(file.getName());
        driverFileGenerator.createOrderRequest(document.getTouchPointGuid(), dataId, document.getEmail(), document.getOrderUuid());
        driverFileGenerator.createOrderRequest1(document.getOrderUuid());
        String id = driverFileGenerator.jobs(document.getOrderUuid());
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        List<String> resultSetFields = driverFileGenerator.getResultFieldData(id);
        if (resultSetFields == null || resultSetFields.size() == 0) {
            log.error("ResultFieldId is empty", resultSetFields);
            return null;
        }

        return driverFileGenerator.downloadFileBasedOnResultsetField(resultSetFields.get(1));

    }

    private File saveXMLFile(String xmlFileName, String xmlContent) {
        File file = null;
        try {
            file = new File(xmlFileName);
            java.io.FileWriter fw = new java.io.FileWriter(file);
            fw.write(xmlContent);
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
            // LOGGER.error("Error saving XML file {}: {}", xmlFileName, e.getMessage());
        }
        return file;
    }
}