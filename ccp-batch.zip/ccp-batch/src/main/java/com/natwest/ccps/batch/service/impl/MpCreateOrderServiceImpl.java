package com.natwest.ccps.batch.service.impl;

import com.natwest.ccps.batch.clients.SoapClient;
import com.natwest.ccps.batch.service.MpCreateOrderService;
import com.natwest.ccps.batch.stub.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class MpCreateOrderServiceImpl implements MpCreateOrderService {
    @Autowired
    Environment environment;
    @Autowired
    SoapClient soapClient;

    public CreateConnectedOrderRequest createConnectedOrderRequest(String externalId, String dataId, String touchpointGuid, List<ConnectedOrderDataPointType> dataPoints) {
        CreateConnectedOrderRequest connectedOrderRequest = initializedOrderReq(touchpointGuid);
        connectedOrderRequest.setAutoApprove(true);
        connectedOrderRequest.setEmail("nikhil.agarwal@natwest.com");
        ConnectedOrderDataPointListType connectedOrderDataPointType = new ConnectedOrderDataPointListType();
        ConnectedOrderDataPointType connectedOrderDataPointType2 = new ConnectedOrderDataPointType();
        connectedOrderDataPointType2.setConnector("CreateProd");
        connectedOrderDataPointType2.setValue("true");


        ConnectedOrderDataPointType connectedOrderDataPointType5 = new ConnectedOrderDataPointType();
        connectedOrderDataPointType5.setConnector("UUID");
        connectedOrderDataPointType5.setValue(externalId);

        ConnectedOrderDataPointType connectedOrderDataPointType6 = new ConnectedOrderDataPointType();
        connectedOrderDataPointType6.setConnector("dataId");
        connectedOrderDataPointType6.setValue(dataId);

        // dataPoints.add(connectedOrderDataPointType1);
        dataPoints.add(connectedOrderDataPointType2);
        // dataPoints.add(connectedOrderDataPointType3);
        dataPoints.add(connectedOrderDataPointType5);
        dataPoints.add(connectedOrderDataPointType6);
        connectedOrderDataPointType.getDataPoint().addAll(dataPoints);
        connectedOrderRequest.setDataPointList(connectedOrderDataPointType);
        connectedOrderRequest.setNewExternalOrderId(externalId);
        log.info("DataPoints " + dataPoints);
        return connectedOrderRequest;
    }

    private CreateConnectedOrderRequest initializedOrderReq(String touchpointGuid) {
        ObjectFactory objectFactory = new ObjectFactory();
        CreateConnectedOrderRequest connectedOrderRequest = objectFactory.createCreateConnectedOrderRequest();
        TouchpointType type = new TouchpointType();
        type.setGuid(touchpointGuid);
        connectedOrderRequest.setTouchpoint(type);
        connectedOrderRequest.setBranchId(environment.getProperty("mp.branch"));
        connectedOrderRequest.setAuthorUsername("NWB-2CP-Users");
        connectedOrderRequest.setCreateProof(true);
        connectedOrderRequest.setNodeId(environment.getProperty("mp.node.id"));
        connectedOrderRequest.setPrerelease(environment.getProperty("mp.pre.release"));
        return connectedOrderRequest;
    }

    public CreateConnectedOrderResponseType createOrder(CreateConnectedOrderRequest connectedOrderRequest, String externalOrderId) {
        log.info("Message point create order Request :: " + connectedOrderRequest);
        CreateConnectedOrderResponseType response = null;
        try {
            response = (CreateConnectedOrderResponseType)
                    soapClient.getResponse(environment.getProperty("mp.url"),
                            connectedOrderRequest);
            log.info("getSuccessResponse  " + response.getSuccessResponse() + "getFailureResponse  " + response.getFailureResponse() + "getNewExternalOrderId  " + response.getNewExternalOrderId());
            if (response.getSuccessResponse() == null) {
                log.error("Order is failed for external order id :: " + externalOrderId + ", Failure response :: " + response.getFailureResponse());
                //throw new RuntimeException(ERRCCP1012_MSG + response.getFailureResponse(), ERRCCP1012);
            }
        } catch (Exception ex) {
            response = new CreateConnectedOrderResponseType();
            response.setFailureResponse("Order is failed for external order id :: " + externalOrderId + ", Failure response :: " + ex.getMessage());
            ex.printStackTrace();
        }
        return response;
    }

}
